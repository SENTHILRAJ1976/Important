package week1.day1;

public class LearnOperator {
public static void main(String[] args) {
	int a = 6, b =12;
	
	// condition ? true block : false block
	System.out.println(a>b ? "a is greater "+a :"b is greater: "+b);
	
	
	
	
	// ++ - Incremental operator -- decreamental operator
	// short hand operator
		/*
		 * a /= 2; System.out.println(a);
		 */
	
}
}
