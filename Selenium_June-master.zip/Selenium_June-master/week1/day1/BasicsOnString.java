package week1.day1;

public class BasicsOnString {
public static void main(String[] args) {
	//String is a non primitive datatype
	String text = "Testleaf";
	int mark = 100;
	System.out.println("My mark is: "+mark);
	
}
}
