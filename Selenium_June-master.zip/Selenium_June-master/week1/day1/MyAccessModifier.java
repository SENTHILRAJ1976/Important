package week1.day1;

public class MyAccessModifier {
public static void main(String[] args) {
	LearnAccessModifiers obj = new LearnAccessModifiers();
	System.out.println(obj.a);
	System.out.println(obj.c);
}
}
