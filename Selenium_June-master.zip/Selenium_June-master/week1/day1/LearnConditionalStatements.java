package week1.day1;

public class LearnConditionalStatements {
public static void main(String[] args) {
	int a = 13, b = 21, c = 35;
	if(a>b && a>c) {
		System.out.println("a is greater");
	}else if(b>a && b>c) {
		System.out.println("b is greater");
	}
	else {
		System.out.println("c is greater");
	}
	
}
}
