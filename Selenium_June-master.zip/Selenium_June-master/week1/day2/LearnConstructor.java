package week1.day2;

class LearnConstructor {
	public   LearnConstructor() {
		System.out.println("Welcome to automation");
	}
	
	public void print() {
		System.out.println("Hello");
	}
public static void main(String[] args) {
	LearnConstructor obj = new LearnConstructor();
	obj.print();
}
}
