package week1.day2;

import week1.day1.*;

public class AccessMods {
public static void main(String[] args) {
	LearnAccessModifiers obj = new LearnAccessModifiers();
	System.out.println(obj.a);
}
}
