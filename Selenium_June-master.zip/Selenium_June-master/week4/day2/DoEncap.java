package week4.day2;

public class DoEncap {
private static int pin = 1234;

// Getter
public int getPin() {
	return pin;
}
// Setter
public void setPin(int newPin) {
	pin = newPin;
}
}
