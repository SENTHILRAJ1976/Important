package week4.day2;

public class Wrappers {
public static void main(String[] args) {
	String text = "Testleaf";
	
	String c = "10";
	int parseInt = Integer.parseInt(c);
	
	int a = 5;
	
	Integer b = 5;
	
}
}
