package week4.day2;

public class GetData {
public static void main(String[] args) {
	DoEncap obj = new DoEncap();
	System.out.println(obj.getPin());
	obj.setPin(1010);
	System.out.println(obj.getPin());
	
}
}
