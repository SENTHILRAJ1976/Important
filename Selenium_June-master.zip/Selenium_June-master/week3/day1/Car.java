package week3.day1;

public final class Car {
public void applyBrake() {
	System.out.println("Apply drum brake");
}

public static void startCar() {
	System.out.println("Ignition start");
}

public final void turnOffCar() {
	System.out.println("Car off");
}
public void turnOnAC() {
	System.out.println("Turn AC");
}
}
