package week3.day1;

public class GoogleChromeDriver extends WebDriverImplementation{
public void launchApp() {
	System.out.println("Launched the application");
}
}
