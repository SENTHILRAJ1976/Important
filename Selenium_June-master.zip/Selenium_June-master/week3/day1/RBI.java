package week3.day1;

public interface RBI {
	
public void openDeposits();
public int minimumBalance = 5000;
}
