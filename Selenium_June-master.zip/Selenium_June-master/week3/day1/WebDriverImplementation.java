package week3.day1;

public class WebDriverImplementation {
public void get(String url) {
	System.out.println("Load the url "+ url);
}
public void close() {
	System.out.println("Close the browser");
}
}
