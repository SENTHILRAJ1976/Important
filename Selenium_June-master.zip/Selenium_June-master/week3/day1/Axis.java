package week3.day1;

public class Axis implements RBI{
	// From interface
	public void openDeposits() {
		System.out.println("Deposit opened");
	}
	// From Implementing class
	public void lendHomeLoans() {
		System.out.println("Provide home loans");
	}

}
