package week3.day2;

public class LearnFinal {
public final int num = 10;
public static void main(String[] args) {
	LearnFinal obj = new LearnFinal();
	obj.num+=10; // final variable can not be modified
}
}
