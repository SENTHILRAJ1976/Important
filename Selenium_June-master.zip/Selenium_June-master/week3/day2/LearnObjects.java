package week3.day2;

public class LearnObjects {
public static void main(String[] args) {
	int[] array = {1,2,3,-1,-4};
	Object[] array1 = {1,-1,1.234F,1.234567,'a',"Text",true};
}
}
