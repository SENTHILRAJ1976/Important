let foodItems = ["idly", "dosa", "puri", "pongal"];

//forEach loops
foodItems.forEach(item => {
    console.log(item);
});

//for loop
for (var i = 0; i < foodItems.length; i++) {
    console.log(foodItems[i]);
}

//while loop
let j = 1;
while (j < 15) {
    console.log(j);
    j++;
}

//unary Operators
/* 
+ 
-
*
/
%
*/
console.log(4 % 3);