//Number Conversion

var deliveryCost = "50";
// deliveryCost = Number(deliveryCost);
var orderCost = 340;
var totalCost = orderCost - deliveryCost;
console.log(totalCost);

//String Conversion
var tips = 50;
var value = String(tips);
console.log(typeof value);

//Boolean Conversion
var foodType = "";
foodType = Boolean(foodType);
console.log(foodType);
