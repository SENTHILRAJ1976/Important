//Single line comment - ctrl + /
/* Multi line Comment - Shift+Alt+A */
console.log("This is First Line");

/* DataTypes
String
Number
BigInt
Boolean
Undefined
Null
*/
//variables
var totalCost = 120.50;
console.log(typeof (totalCost));

let restaurant = "A2B";
restaurant = 1446785987632n;
console.log(typeof restaurant);

var isFoodDelivered = true;
console.log(typeof isFoodDelivered);

let rating;
console.log(typeof rating);

let foodQuality = null;
console.log(typeof foodQuality);

{
    var numberOfOrder = 4;
    var numberOfOrder = "20";

    // let address = "Chennai";
    let address = "prakash";

}
console.log(numberOfOrder);
// console.log(address);

// var let = "Hi";
// var 1Quantity 

const quantity = 5;
// quantity = 6;







