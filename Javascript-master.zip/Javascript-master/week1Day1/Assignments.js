//print all even number betw 1 to 10

// for (let i = 1; i <= 10; i++) {
//     if (i % 2 == 0)
//         console.log(i);
// }


//add all the numbers betw 1 to 10
var temp = 0;
for (let i = 1; i <= 10; i++) {
    temp = temp + i;
}
// console.log(temp);

//multiplication table
var multiplier = 7;
for (let i = 1; i <= 10; i++) {
    console.log(i + "*" + multiplier + "=" + i * multiplier);
}