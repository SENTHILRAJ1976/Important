let ratings = 0;
//switch Case
switch (ratings) {
    case 5:
        console.log("Great Food");
        break;
    case 4:
        console.log("Good Food");
        break;
    case 3:
        console.log("Ok Food");
        break;
    case 2:
        console.log("Bad Food");
        break;
    case 1:
        console.log("Worst Food");
        break;
    default:
        console.log("Rate betw 1 to 5");

}

// if else Conditions

if (ratings > 3) {
    console.log("Greatfood");
} else if (ratings === 3) {
    console.log("ok");
}
else {
    console.log("Bad");
}

