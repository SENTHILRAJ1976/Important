//scheduling - setTimeouts,SetInterval

function waiter() {
    console.log("sir/Ma'am Do u want anything...");    
}
setTimeout(() => {
    waiter();
}, 3000)

