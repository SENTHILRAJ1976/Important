export default class Browser {
    getTitle() {
        return "Title is Received";
    }
}