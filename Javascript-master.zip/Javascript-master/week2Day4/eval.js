let variable = eval("1+1");

console.log(variable);
