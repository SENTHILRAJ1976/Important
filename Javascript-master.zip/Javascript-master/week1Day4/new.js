class Date{

    constructor(format) {
    console.log(format);
    
}

}

let dt = new Date();