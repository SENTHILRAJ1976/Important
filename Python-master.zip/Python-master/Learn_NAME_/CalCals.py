import Learn_NAME_.Calculator

y = Learn_NAME_.Calculator.Cals()
y.add(100, 200)
print(__name__)