class Test_Leaf_v01:

    def registration(self):
        print('registration')


class Test_Leaf_v02:

    def python(self):
        print("Python")



def sample():
    pass


x = Test_Leaf_v01()
